package sw.boot.begin.dto;

import lombok.Data;

@Data
public class DeptDTO {

	private int deptno;
	private String dname;
	private String loc;
}
